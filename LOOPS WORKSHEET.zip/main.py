##  Question 1 
xValue = int(input("Number:"))
y = xValue-0.5
while (y>0):
  print(y)
  y-=0.5

##  Question 2
x=1
while x < 50:
  print(x**(1/2))
  x+=2

##  Question 3 
answer = input("are you left handed ?")
while(answer!="yes"):
  answer = input("are you left handed ?")
print("good")

##   QUESTION 4
answer = input("are you left handed")
while(True):
  answer = input("are you left handed?")