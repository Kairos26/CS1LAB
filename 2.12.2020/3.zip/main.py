a = int(input())
b = int(input())

print('{0} \n{1} \n{2}'.format((a + b), (a - b), (a * b)))


